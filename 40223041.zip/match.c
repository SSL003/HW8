//Sajjad Salimi 40223041

#include <stdio.h>

struct time
{
    int min;
    int sec;
};

struct runner 
{
    char firstName[20];
    char lastName[20];
    int ID;
    struct time *record;
    struct time runningTime;
};

int main()
{
    int n;
    printf("Enter the number of participants\n");
    scanf("%d", &n);

    struct runner list[n];
    struct time t;
    int sortRecord[n];

    for (int i = 0; i < n; i++)
    {
        list[i].record = &t;

        printf("Enter participant %d information\n", i+1);
        scanf("%s%s%d%d%d%d%d", list[i].firstName,list[i].lastName,&list[i].ID,
        &list[i].record->min,&list[i].record->sec,&list[i].runningTime.min,&list[i].runningTime.sec);

        sortRecord[i] = (list[i].record->min)*60+list[i].record->sec;
    }
    
    int win,winTime;
    win = 0;
    winTime = (list[0].runningTime.min)*60+list[0].runningTime.sec;
    int sortTime[n];

    for (int i = 0; i < n; i++)
    {
       sortTime[i] = (list[i].runningTime.min)*60+list[i].runningTime.sec;
    }

    for (int i = 0; i < n; i++)
    {
        if(winTime > sortTime[i])
        {
            win = i;
            winTime = sortTime[i];
        }
    }

    printf("\nThe winner of this match is %s %s",list[win].firstName, list[win].lastName);

    if(sortRecord[win] > sortTime[win])
        printf("\nThe winner could break his own record in this match");
    else 
        printf("\nThe winner could not break his own record in this match");
            
    int winAll=0;
    for (int i = 0; i < n; i++)
        if(sortTime[win] < sortRecord[i])
            winAll++;

    if (winAll == n)
        printf("\nThe winner could break the best record"\
        " of all the participants in this match");
    else 
        printf("\nThe winner could not break the best record"\
        " of all the participants in this match");

    int temp;
    for (int i = 0; i < n; i++)
    {
        for (int j = i; j < n; j++)
        {
            if(sortTime[i] > sortTime[j])
            {
                temp = sortTime[j];
                sortTime[j] = sortTime[i];
                sortTime[i] = temp;
            }
        }
    }
        
    printf("\n\nfirstName\t\tlastName\t\tID\trecord: min sec"\
    "    \t  time: min sec");
    for ( int j = 0; j < n; j++)
    {
        for (int i = 0; i < n; i++)
        {
           if(sortTime[j] == list[i].runningTime.min*60+list[i].runningTime.sec)
            {
                printf("\n%-15s\t\t%-15s\t\t%d\t\t%d   %d\t\t\t%d   %d",
                list[i].firstName,list[i].lastName,list[i].ID,
                sortRecord[i]/60,sortRecord[i]%10,
                list[i].runningTime.min,list[i].runningTime.sec);
                break;
            } 
        } 
    }
return 0;
}